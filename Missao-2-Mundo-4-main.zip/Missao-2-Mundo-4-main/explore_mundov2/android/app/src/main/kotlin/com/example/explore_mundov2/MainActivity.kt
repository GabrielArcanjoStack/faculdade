package com.example.explore_mundov2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
