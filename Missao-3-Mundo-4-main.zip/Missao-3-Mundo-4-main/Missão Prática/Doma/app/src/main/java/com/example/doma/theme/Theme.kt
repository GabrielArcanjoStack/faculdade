package com.example.doma

import androidx.compose.runtime.Composable
import androidx.wear.compose.material.MaterialTheme

@Composable
fun DomaVoiceTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        content = content
    )
}